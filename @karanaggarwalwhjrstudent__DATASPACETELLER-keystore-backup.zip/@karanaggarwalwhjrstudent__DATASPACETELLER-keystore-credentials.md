# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution. 

## Credential Values

- Android keystore password: 81eafd7f794d4da5b0714feb77f2c251
- Android key alias: QGthcmFuYWdnYXJ3YWx3aGpyc3R1ZGVudC9EQVRBU1BBQ0VURUxMRVI=
- Android key password: 619a9b4706c543d69cc5ac1a8c673632
      